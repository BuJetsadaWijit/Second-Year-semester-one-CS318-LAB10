
public class EconomyClass extends Passenger
{
    public EconomyClass(){
        
    }
    
    @Override
    void computeTax(){
        tax = 1000*0.5;
        System.out.println("Economy Class => Compute Tax" + tax);
    }
}