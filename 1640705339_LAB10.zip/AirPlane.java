
import java.util.*;
public class AirPlane
{
    
     List<Passenger> passengers = new ArrayList<>();
    
    public AirPlane(){
        for(int lp = 0; lp < 10; lp++ ){
            passengers.add(new FirstClass());
        }
        
        for(int lp = 0; lp < 10; lp++ ){
            passengers.add(new BusinessClass());
        }
        
        for(int lp = 0; lp < 10; lp++ ){
            passengers.add(new EconomyClass());
        }
    }
    
    public void TestPolymorphism(){
        for(Passenger p : passengers){
            p.computeTax();
        }
    }
}
