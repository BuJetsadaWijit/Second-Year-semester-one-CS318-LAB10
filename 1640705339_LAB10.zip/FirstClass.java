
public class FirstClass extends Passenger
{
    public FirstClass(){
        
    }
    
    @Override
    void computeTax(){
        System.out.println("Frist Class => Compute Tax");
    }
}