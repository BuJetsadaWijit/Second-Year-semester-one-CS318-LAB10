
public class BusinessClass extends Passenger
{
    public BusinessClass(){
        
    }
    
    @Override
    void computeTax(){
        System.out.println("Business Class => Compute Tax");
    }
}