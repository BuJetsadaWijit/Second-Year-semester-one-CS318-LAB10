
public abstract class Passenger
{
  protected String firstName;
  protected String lastName;
  protected String address;
  protected String phoneNumber;
  protected String seatNo;
  protected double tax;
  
  public Passenger(){
      
  }
  
  final void showInfo(){
      System.out.println("Name : " + firstName +  " "+ lastName );
      System.out.println("Seat No : " + seatNo);
      
  }
  
  void computeTax(){
      tax = 100;
  }
  
  protected void computeAll(){
      
  }
  
}
