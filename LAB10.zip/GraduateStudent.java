public class GraduateStudent extends Student{
    public String getCourseGrade() {
        return "";
    }
}