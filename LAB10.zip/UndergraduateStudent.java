public class UndergraduateStudent extends Student {
    public UndergraduateStudent() {
        super();
    }


    public UndergraduateStudent(String pStuName) {
        super(pStuName);
    }

    public String getCourseGrade() {
        return "";
    }
}
