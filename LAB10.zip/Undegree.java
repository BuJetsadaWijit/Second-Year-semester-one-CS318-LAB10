public class Undegree extends Student {
    public String Undegree() {
        return "";
    }
}
