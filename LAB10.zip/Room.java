public class Room {

    public int cnt;

    public static void main(String[] args) {
        Student[] roster = new Student[40];

        roster[0] = new GraduateStudent();
        roster[1] = new UndergraduateStudent();
        roster[2] = new Undegree();
        //roster[0] = new Student();

        //Student stu = new roster[1];

        UndergraduateStudent Ustu = new UndergraduateStudent();
        String name = Ustu.getName();

        int UndergraduateCount = 0;

        for(Student stu : roster){
            if(stu != null && stu instanceof UndergraduateStudent){
                UndergraduateCount++;
            }
        }
    }
}
