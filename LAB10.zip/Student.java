public abstract class Student{
    public static final int NUM_OF_TEST = 3;
    protected String name;
    //protected String test;
    protected int[] test;
    protected String courseGrade;

    //public String type = '';

    //Default super class
    public Student() {
        int[] test = new int[NUM_OF_TEST];
    }

    //Overloading super class
    public Student(String pName) {
        this.name = pName;
        int[] test = new int[NUM_OF_TEST];
    }

    public String getCourseGrade() {
        return this.courseGrade;
    }

    public String getName() {
        return this.name;
    }

    public int getTestScore(int pNumOfTest) {
        return this.test[pNumOfTest-1];
    }

    public void setName(String pName) {
        this.name = pName;
    }

    public void setTestScore(int pNumOfTest, int pScore) {
        if(this.test == null){
            this.test = new int[NUM_OF_TEST];
        }

        this.test[pNumOfTest-1] = pScore;
    }
}